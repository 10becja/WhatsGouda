<?php include "./backEnd/base.php"; $_SESSION = array(); session_destroy(); ?>
<?php include "navbar.php"; ?>
	<h1>Goodbye!</h1>
<meta http-equiv="refresh" content="1;/">

	</div>
  </body>
</html>
